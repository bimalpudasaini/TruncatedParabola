# -*- coding: utf-8 -*-
"""
Created on Thu Mar 30 11:19:56 2017

@author: bimal
"""

from Tunneling import calcKappa, critTemp
import numpy as np
import math

import matplotlib, sys
#matplotlib.use('TkAgg')
from numpy import arange, sin, pi, interp
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure
from tkinter import *

# import matplotlib.pyplot as plt
Kb = 1.3806 * 10**-23       #  Boltzmann constant
hbar = 1.0546 * 10**-34     #  Reduced Plank constant
C = 299792458               #  Speed of light
NA = 6.022 * 10**23         #  Avogadro's Number

R = 8.314  # J/(K mol)


def kappaData (barrier, rxnE, freq, itemp, ftemp, npoints):
    init_temp = float(itemp)
    final_temp = float(ftemp)
    # set initial temperature lower
    if init_temp > final_temp:
        a = init_temp
        b = final_temp
        final_temp = a
        init_temp = b
        
    data_points = int(npoints)
    
    if(init_temp > 0 and final_temp > 0):
        if (data_points > 0):
            temp_gap = (final_temp - init_temp)/data_points
        else:  
            temp_gap = (final_temp - init_temp)/10
    else:
        messagebox.showinfo("Execution Error !!", "Temprature Data Missing !!")
    # 
    
    counter=0
    kappaDATA_X = []
    kappaDATA_Y = []

    # araange initial and final temperature as the end points
    temp_range = np.arange(init_temp, final_temp + temp_gap, temp_gap)
    Tc = critTemp(freq)
    leftTc = 0
    rightTc = 0
    
    # set the limits in temperature near critical points Tc
    for x in temp_range:
        if x+10  <= Tc:
            leftTc = x
        if x-10 >= Tc:
            rightTc = x
            break
     
    for i in temp_range:
        #Tc = critTemp(freq)
        test = abs(Tc -i)/2
    	# remove temperature near critical temperature (Tc)
    	# this is because the function is unphysical near Tc
        
        if test > 5: 
            kappaDATA_X.append(i)
            kappaDATA_Y.append(calcKappa(barrier, rxnE, freq, i))
            counter = counter + 1
	
        if test < 5:
            kappaDATA_X.append(i)
            kappaDATA_Y.append(interpolate(barrier, rxnE, freq, i, leftTc, rightTc))
    

    # start plotting
    # print(critTemp(freq))
    # print (kappaDATA_X[0:counter])
    return kappaDATA_X, kappaDATA_Y

# interpolate data 
def interpolate(barrier, rxnE, freq, i, leftTc, rightTc):
    xp = [leftTc, rightTc]
    yp = [calcKappa(barrier, rxnE, freq, leftTc), calcKappa(barrier, rxnE, freq, rightTc)]
    val = interp(i, xp, yp)  # linear interpolation 
    return val

#
def EyringData(Xkappa, Ykappa, G_Barrier):
    k_classical = []
    k_tunneling = []
    count = 0    
    for j in Xkappa:
        prefactor = 2 * math.pi * Kb * j / hbar
        DFT_K = prefactor * math.exp((-1)*G_Barrier[count] * 1000/ (R * j))
        k_classical.append(DFT_K)
        Tunn_K = Ykappa[count] * DFT_K
        k_tunneling.append(Tunn_K)
        count = count + 1
    
    return k_classical, k_tunneling



def generatePlot(temperature, kappa, kDFT, kTunnel):
    master = Tk()
    master.title("Output-Plots")
    #-------------------------------------------------------------------------------

    f = Figure(figsize=(6,9), dpi=100)
    t = arange(0.0,3.0,0.05)
    ax0 = f.add_axes((0.2, .60, .70, .35))
    ax1 = f.add_axes((0.2, .1, .70, .35))
   
    #-------------------------------------------------------------------------
    ax0.set_title("Kappa vs. Temperature")
    ax0.set_xlabel( 'Temperature' )
    ax0.set_ylabel( 'Value') 
    
    ax1.set_title("Eyring Plot (Theoretical)")
    ax1.set_xlabel( '1/T' )
    ax1.set_ylabel( 'ln(k/T)') 
    
    #--------------------------------------------------------------------------
    eyringX =[]
    eyringY = []
    eyringYTunn = []
    
    count = 0    
    for t in temperature:
        eyringX.append(1/t)
        eyringY.append(math.log(kDFT[count]/t))
        eyringYTunn.append(math.log(kTunnel[count]/t))
        count = count + 1
    
    ax0.plot(temperature, kappa,"r-", marker ='o')
    ax1.plot(eyringX, eyringY, "r-", marker ='o')
    ax1.plot(eyringX, eyringYTunn, "g-", marker ='o')
    
    #--------------------------------------------------------------------------
    
    frame = Frame(master)
    frame.pack(side=BOTTOM, fill=BOTH, expand=1)
 
    dataPlot = FigureCanvasTkAgg(f, master=master)
    dataPlot.get_tk_widget().pack(side=TOP, fill=BOTH, expand=1)
    dataPlot.show()
    #-------------------------------------------------------------------------------
    
    toolbar = NavigationToolbar2TkAgg(dataPlot,frame)
    toolbar.pack()
    toolbar.update()
    
   
    master.mainloop()

   
    
