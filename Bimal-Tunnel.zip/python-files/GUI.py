# -*- coding: utf-8 -*-
"""
Created on Tue Apr 11 19:34:25 2017

@author: bimal
"""
from tkinter import *
from tkinter import filedialog
import os
from Application import start

master = Tk()
global chemistryPackages 
chemistryPackages = ["Gaussian 09"] #Orca    3.0.2","PSI4       1.0"]   # text field 12 

class GUI(Frame):
    #initializaion of the class
    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.filename = None
        self.grid()
        self.createWidgets()
                
    
    def createWidgets():
        # screw the object oriented programming 
        # procedural programing is  easy to write and debug
        
        # set the properties of the window
        master.title("Truncated Parabola Approximation - Barrier Tunneling")  # title
        master.resizable(width=False, height=False)  # not resizable
        master.minsize(width=720, height=380)        # fixed size
        master.maxsize(width=720, height=380)
        
        # labels defination, Reactant TS and Products
        GUI.createLabels()
        
        # define Entry for Labels 
        global def_varR, def_varTS, def_varP
        
        def_varR = "< -- Reactant Path -->"
        def_varTS = "< -- TS Path -->"
        def_varP = "< -- Product Path -->"
        
        GUI.createEntry(def_varR, def_varTS, def_varP)
                
        # we should be able to browse the files using browse button
        GUI.createButtons()
        
        # labels for temperature range 
        GUI.createTempWidgets()
        
        # horizontal line separator
        GUI.drawLine(3, 5)  
                
        # insert text box inside a frame
        GUI.showInstructions()
        # Solvation stuffs
        GUI.createSolvWidgets()
        
        GUI.drawLine(8, 5) 
                
        # drop down menu for quantum chemistry package        
        GUI.createMenu()
        
        # quantum chemistry package address
        GUI.createExecWidgets()
        
        # GUI last buttons clear and calculate
        GUI.createRunButtons()
        
        # developer info
        GUI.showDeveloper()
           
        # done creating, show window in a loop 
        master.mainloop()
        
        
    def getFilePath(geometry):
        cwd = os.getcwd()
        filename  = filedialog.askopenfilename(initialdir=cwd,
                                                   filetypes = (("G09 Chk file","*.chk"),
                                                                ("All files","*.*")))
        if (geometry == "reactant"):
                rEntry.delete(0,END)
                rEntry.insert(0,filename)
        
        if (geometry == "product"):
                pEntry.delete(0,END)
                pEntry.insert(0,filename)
        
        if (geometry == "TS"):
                tsEntry.delete(0,END)
                tsEntry.insert(0,filename)
                
    def getExecPath():
        cwd = os.getcwd()
        execPath = filedialog.askdirectory(initialdir=cwd)
        execEntry.delete(0,END)
        execEntry.insert(0,execPath)
        
        
    def createLabels():
        # self.createLabels() 
        rLabel = Label(master, text="Reactant", font="Times")
        tsLabel = Label(master, text="Transition State", font="Times")
        pLabel = Label(master, text="Product",font = "Times")
        
        # labels positions
        rLabel.grid(row=0, sticky =E, padx=15, pady=5)
        tsLabel.grid(row=1, sticky=E, padx=15, pady=5)
        pLabel.grid(row=2, sticky=E, padx=15, pady=5)
        
    def createEntry(varR, varTS, varP):
        global rEntry
        rEntry = Entry(master, bg="white", width=35)
        rEntry.insert(INSERT, varR)
        
        global tsEntry
        tsEntry = Entry(master, bg="white", width=35)
        tsEntry.insert(INSERT, varTS)
        
        global pEntry
        pEntry = Entry(master, bg="white", width=35)
        pEntry.insert(INSERT, varP)
        
        # positions of the entries
        rEntry.grid(row=0, column=1)
        tsEntry.grid(row=1, column=1)
        pEntry.grid(row=2, column=1)
        
    def createButtons():
        rButton = Button(master, text="Browse", font="Times", command= lambda: GUI.getFilePath("reactant"))
        tsButton = Button(master, text="Browse",font="Times", command= lambda: GUI.getFilePath("TS"))
        pButton = Button(master, text="Browse", font="Times", command= lambda: GUI.getFilePath("product"))
        
        # positions of the browse buttons
        rButton.grid(row=0, column=2)
        tsButton.grid(row=1, column=2)
        pButton.grid(row=2, column=2)
    
    def createTempWidgets():
        global initTempEntry
        global finalTempEntry
        global dataEntry
        
        initTempLabel = Label(master, text="Init. Temp. (K)", font="Times")
        finalTempLabel = Label(master, text="Final Temp. (K) ", font="Times")
        dataLabel = Label(master, text="Data points (n)", font="Times")
        
        # locations
        initTempLabel.grid(row=0, column=3, sticky=E, padx=15, pady=5)
        finalTempLabel.grid(row=1, column=3, sticky=E, padx=15, pady=5)
        dataLabel.grid(row=2, column=3, sticky=E, padx=15, pady=5)
        
        # user is required to enter temperature and pressure using entries.
        initTempEntry = Entry(master, bg="white", width =10)
        finalTempEntry = Entry(master, bg="white", width =10)
        dataEntry  = Entry(master, bg="white", width =10)
        
        initTempEntry.insert(INSERT, 0)
        finalTempEntry.insert(INSERT, 0)
        dataEntry.insert(INSERT, 0)
        
        # postions of entries
        initTempEntry.grid(row=0, column=4)
        finalTempEntry.grid(row=1, column=4)
        dataEntry.grid(row=2, column=4)
    
    def drawLine(x, y):
        drawArea = Canvas(master, width=710, height=10, bg="dark green")
        drawArea.grid(row=x, columnspan=y, pady=5)
    
    def showInstructions():
        initial = "Steps: \n"
        step1 = "1. Define the paths to checkpoint files (Reactant, TS, etc.) \n   containing force constant data. \n"
        step2 = "2. Enter initial and final reaction temperatures, \n   and the number of desired data points. \n"
        step3 = "3. If solvation effects are desired, add  \u0394G of solvation, \n   otherwise leave zeroes. \n"
        step4  = "4. Define the path to the quantum chemistry package, \n   and hit calculate. \n"
        
        
        textInstruction = initial + step1 + step2 + step3 + step4
        
        TextArea = Text(master, width=68, height =10, bg="White")
        TextArea.grid(row=4, column=0, rowspan=4, columnspan=3)
        TextArea.insert(INSERT, textInstruction)
        TextArea.config(state="disabled")
    
    def createSolvWidgets():
        global rSolvEntry, tsSolvEntry, pSolvEntry
        
        solvLabel= Label(master, text="\u0394G Solvation (a.u)", font="Times", fg="blue")
        solvLabel.grid(row=4, column=3, columnspan=2, padx=20, pady=5, sticky=E)
        
        # Reactant Solvation
        rSolvLabel = Label(master, text="Reactant", font="Times")
        tsSolvLabel = Label(master, text="Transition State", font="Times")
        pSolvLabel = Label(master, text="Product", font="Times")
        
        rSolvLabel.grid(row=5, column=3, sticky=E, padx=15, pady=5)
        tsSolvLabel.grid(row=6, column=3, sticky=E, padx=15, pady=5)
        pSolvLabel.grid(row=7, column=3, sticky=E, padx=15, pady=5)
        
        rSolvEntry = Entry(master, bg="white", width =10)
        tsSolvEntry = Entry(master, bg="white", width =10)
        pSolvEntry = Entry(master, bg="white", width =10)
        
        rSolvEntry.grid(row=5, column=4, pady=5)
        tsSolvEntry.grid(row=6, column=4, pady=5)
        pSolvEntry.grid(row=7, column=4, pady=5)
        
        rSolvEntry.insert(INSERT, 0)
        tsSolvEntry.insert(INSERT, 0)
        pSolvEntry.insert(INSERT,0)
        
    def createMenu():
        global var
        var = StringVar(master)
        var.set(chemistryPackages[0])
        
        global choosePackage
        choosePackage = OptionMenu(master, var, *chemistryPackages)
        choosePackage.grid(row=9, column=0, padx=15, pady=5)
        choosePackage.config(font="Times",bg='white')
    
    def createExecWidgets():
        global execEntry
        execEntry = Entry(master, bg="white", width=35)
        execEntry.grid(row=9, column=1)
        execEntry.insert(INSERT, "Choose Software Directory")
        
        execButton = Button(master, text="Browse", font="Times", command=GUI.getExecPath)
        execButton.grid(row=9, column=2)
        
        #execLabel= Label(master, text="Executible Path Directory", font="Times", fg="blue")
        #execLabel.grid(row=9, column=3, columnspan=2, padx=20, pady=5, sticky=E)
    
    def createRunButtons():
        runButton = Button(master, text="Calculate", font="Times", command=GUI.calculate)
        runButton.grid(row=9, column=4, pady=5, sticky = W)
        
        clearButton = Button(master, text="Clear", font="Times", command=GUI.clear)
        clearButton.grid(row=9, column=3, pady=5, sticky = E)
    
    def showDeveloper():
        developer = "Developer \u2013 Bimal Pudasaini, PhD"
        authorLabel = Label(master, text=developer, font="Times", fg="white", bg="gray22", width=90)
        authorLabel.grid(row=10, column=0, columnspan =5, pady=5)
   
    
    def clear():
        execEntry.delete(0,END)
        
        # reset Reactant
        rEntry.delete(0,END)
        rEntry.insert(INSERT, def_varR)
        
        # reset TS
        tsEntry.delete(0,END)
        tsEntry.insert(INSERT, def_varTS)
        
        # reset Product
        pEntry.delete(0,END)
        pEntry.insert(INSERT, def_varP)
        
        # reset Solvation
        rSolvEntry.delete(0,END)
        tsSolvEntry.delete(0,END)
        pSolvEntry.delete(0,END)
        
        rSolvEntry.insert(INSERT, 0)
        tsSolvEntry.insert(INSERT, 0)
        pSolvEntry.insert(INSERT,0)
        
        # reset temperature data
        initTempEntry.delete(0,END)
        finalTempEntry.delete(0,END)
        dataEntry.delete(0,END)
        
        initTempEntry.insert(INSERT, 0)
        finalTempEntry.insert(INSERT, 0)
        dataEntry.insert(INSERT, 0)
        
        # reset menu
        var.set(chemistryPackages[0])
        execEntry.delete(0,END)
        execEntry.insert(INSERT, "Choose Software Directory")
     
    def calculate():
        pathReactant = rEntry.get()
        pathProduct  = pEntry.get()
        pathTS = tsEntry.get()
        
        pathExec = execEntry.get()
        
        initTemp = initTempEntry.get()
        finalTemp = finalTempEntry.get()
        dataPoints = dataEntry.get()
           
        solvReactantG = rSolvEntry.get()
        solvTSG = tsSolvEntry.get()
        solvProductG = pSolvEntry.get()
        
        software = var.get()
        
        indexVar =[pathReactant, pathTS, pathProduct, software, pathExec, initTemp,
                    finalTemp, dataPoints, solvReactantG, solvTSG, solvProductG]
        
        start(indexVar)
        
