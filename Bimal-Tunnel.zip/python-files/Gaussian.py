# -*- coding: utf-8 -*-
"""
Created on Sat Mar 18 09:41:28 2017

@author: bimal Pudasaini
"""



import subprocess
import os

from tkinter import messagebox

# run freqcheck on each indicated file 

def getSCF(path2FormCHK, path2CHK):
    # create a data file, 
    dataFile = open("formCHK.data","w+")
    try:
        # run formCHK utility to generate formatted checkpoint in *data file
        subprocess.call([path2FormCHK, path2CHK, "formCHK.data"])
    except:
        messagebox.showinfo("formchk Error !!", "Can not Process CHK file")
    # open *data file for reading
    dataFile = open("formCHK.data", "r")
    # search for SCF Energy
    for line in dataFile:
        if "SCF Energy" in line :
            grabSTR = line.split()
            # we would split the line into words 
            # grab the last sting in the array of words
            try:
                scf = float(grabSTR[-1])
                # convert the string to float type
                break
            except:
                messagebox.showinfo("Error !!", "Unable to read CHK files ")
                break
    dataFile.close()
    os.remove("formCHK.data")
    return scf


def getGibbs(path2FreqCHK, path2CHK, temperature):
    # create a data file, 
    # too much meomory required if not written to a file
    dataFile = open("freqCHK.data","w+") 
    # convert temperature and pressure to a string
    if temperature > 0:
        tem = str(temperature)
        # pres = str(pressure)
        # define the command that goes in the subprocess 
        command = [path2FreqCHK, path2CHK, "-o", "freqCHK.data", 
        "N", tem, "0", "1", "Y", "N" ]
        # open *data file for reading
        subprocess.call(command)
    
        ZPE = getZPE()
        freq = getFreq()
        Gcorr = getGibbsCorr()
        dataFile.close()
        os.remove("freqCHK.data")
        return [freq, ZPE, Gcorr]
    
    else:
        messagebox.showinfo("Seriously, Gibbs energy at absolute Zero ?")
        

def getZPE():
    dataFile = open("freqCHK.data", "r")
    for line in dataFile:
        if "Zero-point correction=" in line :
            grabSTR = line.split()
            # we would split the line into words 
            # grab the last sting in the array of words
            try:
                ZPE = float(grabSTR[-2])
                # convert the string to float type
                break
            except:
                ZPE = 0
                break
    dataFile.close()
    return ZPE



def getGibbsCorr():
    dataFile = open("freqCHK.data", "r")
    for line in dataFile:
        if "Gibbs Free Energy=" in line :
            grabSTR = line.split()
            try:
                Gibbs = float(grabSTR[-1])
                # convert the string to float type
                break
            except:
                Gibbs = 0
                break
    dataFile.close()
    return Gibbs



def getFreq():
    dataFile = open("freqCHK.data", "r")
    for line in dataFile:
        if "Frequencies" in line :
            grabSTR = line.split()
            try:
                freq = float(grabSTR[2])
                break
                # convert the string to float type
            except:
                Gibbs = 0
                break
    dataFile.close()
    return freq
    
