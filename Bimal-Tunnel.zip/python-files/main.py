# -*- coding: utf-8 -*-
"""
Author : Bimal Pudasaini

"""
# GUI support
from GUI import *

GUI.createWidgets()

