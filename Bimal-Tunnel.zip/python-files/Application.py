# -*- coding: utf-8 -*-
"""
Created on Sun Apr  9 19:42:32 2017

    pathReactant = data[0]
    pathTS = data[1]
    pathProduct  = data[2]
    
    software = data[3]
    pathExec = data[4]
        
    initTemp = data[5]
    finalTemp = data[6]
    dataPoints = data[7]
           
    solvReactantG = data[8]
    solvTSG = data[9]
    solvProductG = data[10]
    formchk = data[11]
    freqchk = data[12]

@author: bimal
"""

import os
from Gaussian import *
import math
from plotData import *
import numpy
from tkinter import messagebox
from time import gmtime, strftime


def start(data):
    # check software  
    if (data[3] == "Gaussian 09"):
        startGaussian(data)
    
    if (data[3] == "Orca    3.0.2"):
        startOrca(data)
    
    if (data[3] == "PSI4       1.0"):
        startPSI4(data)

def startGaussian(data):
    # validate the executibles, and geometry paths
    # validate 
    testFiles = False
    testFormCHK = False
    testFreqCHK = False
    if os.path.isfile(data[0]) and data[0].endswith(".chk"):
        if os.path.isfile(data[1]) and data[1].endswith(".chk"):
            if os.path.isfile(data[2]) and data[1].endswith(".chk"):
                testFiles = True
            # messagebox.showinfo("well done !", "Gaussian CHK files found")
    if(testFiles == False):
        messagebox.showinfo("File Error !!", "Gaussian CHK Files Required")
    
    try:       
        GaussPath = next(os.walk(data[4]))[0]
    
    except:
         messagebox.showinfo("Error !!", "Gaussian Directory NOT FOUND")
    
    path2FormCHK = ""
    path2FreqCHK = ""
    
    if  os.path.isdir(GaussPath):
        files = next(os.walk(GaussPath))[2]
        for name in files:
                if name == "formchk":
                    path2FormCHK = os.path.abspath(os.path.join(GaussPath, name))
                    #messagebox.showinfo("Good !!", path2FormCHK)
                    #flag = 1
                    testFormCHK = True      
                    
                if name == "freqchk":
                    path2FreqCHK = os.path.abspath(os.path.join(GaussPath, name))
                    testFreqCHK = True
    
    
    if(testFormCHK == False):
        messagebox.showinfo("Execution Error !!", "Gaussian formchk NOT FOUND")
    
    if(testFormCHK == False):
        messagebox.showinfo("Execution Error !!", "Gaussian freqchk NOT FOUND")
                
                    

    if testFiles and testFormCHK and testFreqCHK:
        processGaussian(data, path2FormCHK, path2FreqCHK)
        
           
               
    
def processGaussian(data, path2FormCHK, path2FreqCHK):
    #mybar = ttk.Progressbar(progressBar, orient=HORIZONTAL, length=200, mode='determinate')
    #mybar.pack()
    
    reactantSCF = getSCF(path2FormCHK, data[0])  # getSCF defined in Gaussian.py
    tsSCF = getSCF(path2FormCHK, data[1])
    productSCF =  getSCF(path2FormCHK, data[2])
        
    # get zeropoint energy  return values [freq, ZPE, Gcorr]
    rData = getGibbs(path2FreqCHK, data[0], 298.15)  # default run
    tsData = getGibbs(path2FreqCHK, data[1], 298.15)
    pData = getGibbs(path2FreqCHK, data[2], 298.15)
    
    V_Reactant = reactantSCF + rData[1]
    V_TS = tsSCF + tsData[1]
    V_Product = productSCF + pData[1]
    
    V_barrier = (V_TS - V_Reactant)*2625.5      # kJ/mol
    V_Energy =  (V_Product - V_Reactant)*2625.5          # kJ/mol
    # calculate kappa as a function of temperature
    if V_barrier > 0 :
        [tempRange,kappa] = kappaData(V_barrier, V_Energy, tsData[0], data[5], data[6], data[7])
        #print(kappa)
        GibbsTS = []
        GibbsR = []
        Gibbs_barrier = []
               
        for i in tempRange:
            G_TS_solv = float(data[9])
            
            # G_TS_solv  is solvation correction
            # getGibbs returns Gcorr 
            G_TS = tsSCF + G_TS_solv + getGibbs(path2FreqCHK, data[1], i)[2]
            G_R_solv = float(data[8])
            
            G_Reactant = reactantSCF  +  G_R_solv + getGibbs(path2FreqCHK, data[0], i)[2]
            
            GibbsTS.append(G_TS * 2625.5)
            GibbsR.append(G_Reactant * 2625.5)
            Gibbs_barrier.append((G_TS-G_Reactant)*2625.5)
            
        
        # data for Eyring plot
        [kDFT, kTunnel] = EyringData(tempRange, kappa, Gibbs_barrier)
        # save data in a File Gausian DATA: name of file TS.chk.data
        writeToFile(tempRange, kappa, kDFT, kTunnel,"Gaussian.data", data)
        
        generatePlot(tempRange, kappa, kDFT, kTunnel)
    
    else:
        messagebox.showinfo("INPUT Error !!", "Barrier not greater than zero !!")
    
def writeToFile(var1, var2, var3, var4, var5, var6):
    # save the file in same location as var6
    directory, filename =  os.path.split(var6[0])
    outFILE = os.path.join(directory, var5)
    f = open(outFILE, "a")
    # Things to write : Date and Time, Input Parameters, Output Data
    showtime = strftime("%Y-%m-%d %H:%M:%S", gmtime())
    f.write(showtime + "\t Results \n")
    f.write("----------------------------------------------------------\n")
    f.write("\t Input Parameters \n\n")
    f.write("\t Initial Temperature = " + var6[5])
    f.write("\n\t Final Temerature = " + var6[6])
    #f.write("\n\t Pressure = 1 atm")
    f.write("\n\t Data points = " + var6[7])
    f.write("\n\t \u0394G Solvation Reactant = " + var6[8])
    f.write("\n\t \u0394G Solvation TS = " + var6[9])
    f.write("\n\t \u0394G Solvation Product = " + var6[10])
    f.write("\n\t Vibrational scaling = 1.0")
    f.write("\n\t Pressure = 1 atm")

    # write outputs 
    f.write("\n----------------------------------------------------------\n")
    f.write("\t Output Parameters \n\n")
    f.write("Temperature \t Tunneling Factor(\u03BA)  \t\t k(DFT) \t\t k(Tunnel) \n")
    
    # loop throug the data
    i = 0
    for temp in var1:
        Temperature = str(temp) 
        f.write(Temperature)
        f.write("\t\t\t") 
        
        kappa = str("%.2f" %var2[i])
        f.write(kappa)
        f.write("\t\t")

        kDFT = str(var3[i])
        f.write(kDFT)
        f.write("\t\t")
        
        kTunn = str (var4[i])
        f.write(kTunn)
        f.write("\n")
        i = i + 1
    #
    f.write("\n--------------------------------------------------------------\n END") 
    
    
 



    
