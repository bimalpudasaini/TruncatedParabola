# -*- coding: utf-8 -*-
"""
Author : Bimal Pudasaini
March 17, 2017

Location: Kathmandu, Nepal
"""
import math
import numpy as np

Kb = 1.3806 * 10**(-23)       #  Boltzmann constant
hbar = 1.0546 * 10**(-34)     #  Reduced Plank constant
C = 299792458               #  Speed of light
NA = 6.022 * 10**23         #  Avogadro's Number

    
def calcKappa(barrier,rxnE, freq, temperature):
    
    omega = abs(2*math.pi*freq)* C * 100
    
    # calculate alfa   
    A = 2*math.pi/ (hbar * omega) * 10**(-20)
    
    # calculate beta
    B = 1/(Kb * temperature)  * 10**(-20) 
    V_TS = barrier
    # set exothermicity to zero.      
    if rxnE < 0:
        V_R = 0
    else:
        V_R = rxnE

    # exponent term
    val = (B-A)/(6.022)
    exponent = np.exp(val*(V_TS-V_R))
    
  
    # beta/ (beta - alfa)
    x = B/(B-A)
    # check whether Alfa > Beta
    if B > A :
        kappa = exponent *(x-1)
    else:
        kappa =  (B/A * math.pi)/math.sin(B/A * math.pi) + exponent * B/A

    return kappa   
   
   
def critTemp(freq):
    omega = abs(2*math.pi*freq)* C * 100
    # calculate Tc
    Tc = hbar * omega / (2* math.pi* Kb)
    return Tc

    